---
title: "DeustoKOM News"
date: 2019-11-19T16:37:47+01:00
summary: Revista digital de estudiantes de Comunicación de la Universidad de Deusto.

# Optional external URL for project (replaces project detail page).
external_link: http://deustokom.news

image:
  caption: Captura del sitio DeustoKOM News
  focal_point: Smart


links:
- icon: twitter
  icon_pack: fab
  name: Seguir en Twitter
  url: https://twitter.com/DeustoKomunika
---

